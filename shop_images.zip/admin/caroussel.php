<?php session_start(); 

if (isset($_SESSION['typeAdmin'])) {
  if ($_SESSION['typeAdmin'] != 'super') {
    header("location:products.php");
  }
}else{
  header("location:products.php");
}

?>
<?php include_once("./templates/top.php"); ?>
<?php include_once("./templates/navbar.php"); ?>
<div class="container-fluid">
  <div class="row">
    
    <?php include "./templates/sidebar.php"; ?>

      <div class="row">
      	<div class="col-10">
      		<?php include "./classes/caroussel.php"; ?>
      	</div>
        <div class="col-10">
          <h2>Liste de caroussel</h2>
        </div>
      	<div class="col-2">
      		<a href="#" data-toggle="modal" data-target="#add_caroussel_modal" class="btn btn-primary btn-sm">Ajouter un caroussel</a>
      	</div>
      </div>
      
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>#</th>
              <th>Image</th>
              <th>Text</th>
              <th>Marque</th>
              <th>Etat</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="caroussel_list">
            <?php 
              $all_c = get_caroussel();
              if ( $all_c) {
                $i = 1;
                foreach ($all_c as $k => $v) {
            ?>
                <tr>
              <td><?= $i ?></td>
              <td><img width="200" src="../caroussel_images/<?= $v['caroussel_image'] ?>"><span style="display: none" id="caroussel_image_<?= $v['caroussel_id'] ?>"><?= $v['caroussel_image'] ?></span></td>
              <td id="caroussel_title_<?= $v['caroussel_id'] ?>"><?= $v['caroussel_title'] ?></td>
              <td><?= $v['caroussel_brand'] ?></td>
              <td class="text-<?= ($v['etat'] == 1)? 'success' : 'danger' ?>"><?= ($v['etat'] == 1)? 'Activé' : 'Désactivé' ?></td>
              <td>
                
                <form method="POST">
                  <input type="hidden" name="cid" value="<?= $v['caroussel_id'] ?>">

                  <a href="#" class="btn btn-sm btn-info" onclick="update('<?= $v['caroussel_id'] ?>'); return false;" data-toggle="modal" data-target="#edit_caroussel_modal">Update</a>
                  <button class="btn btn-sm btn-danger" name="delete_Caroussel">Delete</button>
                  <?php if($v['etat'] == 1){ ?>
                    <button class="btn btn-sm btn-warning" name="desactive_etat_caroussel">Désactiver</button>
                  <?php }else{?>
                    <button class="btn btn-sm btn-success" name="active_etat_caroussel">Activer</button>
                  <?php }?>


                </form>
                
              </td>
            </tr>
            <?php
            $i++;
                }
              }
              

            ?>
            
          </tbody>
        </table>
      </div>
    </main>
  </div>
</div>



<!-- Ajouter un caroussel Modal start -->
<div class="modal fade" id="add_caroussel_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ajouter un caroussel</h5>
        <button type="submit" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="add-caroussel-form" enctype="multipart/form-data" method="POST" >
        	<div class="row">
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Description du caroussel</label>
		        		<textarea class="form-control" name="e_caroussel_name" placeholder="Entrer Description du caroussel"></textarea>
		        	</div>
        		</div>
            <div class="col-12">
        			<div class="form-group">
		        		<label>Image du caroussel<small>(format: jpg, jpeg, png)</small></label>
		        		<input type="file" name="caroussel_image" class="form-control">
		        	</div>
        		</div>
				<div class="col-12"><!--DMK-->
        			<div class="form-group">
		        		<label>Marque</label>
		        		<select class="form-control brand_list" name="brand_id">
		        			<option value="">Sélectionnez la marque</option>
		        		</select>
		        	</div>
        		</div>
        		<div class="col-12">
        			<button type="submit" name="add_caroussel" class="btn btn-primary add-caroussel">Ajouter un caroussel</button>
        		</div>
        	</div>
        	
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Ajouter un caroussel Modal end -->

<!-- Edit Product Modal start -->
<div class="modal fade" id="edit_caroussel_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ajouter un caroussel</h5>
        <button type="submit" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="edit-caroussel-form" enctype="multipart/form-data" method="POST">
          <div class="row">
            <div class="col-12">
              <div class="form-group">
                <input type="text" name="cid" id="cid" class="form-control">
                <label>Description du caroussel</label>
                <textarea class="form-control" name="e_caroussel_name" placeholder="Entrer product desc" id="e_caroussel_name"></textarea>
              </div>
            </div>
            <div class="col-12">
              <div class="form-group">
                <label>Image du caroussel<small>(format: jpg, jpeg, png)</small></label>
                <input type="file" name="e_caroussel_image" class="form-control">
              </div>
            </div>
			<div class="col-12"><!--DMK-->
        			<div class="form-group">
		        		<label>Marque</label>
		        		<select class="form-control brand_list" name="e_brand_id">
		        			<option value="">Sélectionnez la marque</option>
		        		</select>
		        	</div>
        		</div>
            <div class="col-12">
              <button type="submit" name="edit_caroussel" class="btn btn-primary submit-edit-caroussel">Modifier un caroussel</button>
            </div>
          </div>
          
        </form>
      </div>
    </div>
  </div>
</div>
<!-- Edit Product Modal end -->

<?php include_once("./templates/footer.php"); ?>

<script type="text/javascript">
  function update(cid){
    $("#e_caroussel_name").val($("#caroussel_title_"+cid).text());
    $("#cid").val(cid);
  }
</script>

<script type="text/javascript" src="./js/products.js"></script>
<script type="text/javascript" src="./js/caroussel.js"></script>