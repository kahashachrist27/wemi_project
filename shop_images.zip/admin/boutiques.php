<?php session_start(); ?>
<?php include_once("./templates/top.php"); ?>
<?php include_once("./templates/navbar.php"); ?>
<div class="container-fluid">
  <div class="row">
    
    <?php include "./templates/sidebar.php"; ?>

      <div class="row">
      	<div class="col-10">
      		<h2>Liste de boutiques</h2>
      	</div>
      	<div class="col-2">
      		<a href="#" data-toggle="modal" data-target="#add_shop_modal" class="btn btn-primary btn-sm">Ajouter une boutique</a>
      	</div>
      </div>
      
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>#</th>
              <th>Nom</th>
              <th>Image</th>
              <th>Catégorie</th>
              <th>Addresse</th>
              <th>Contact 1</th>
              <th>Contact 2</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="shop_list">
            
          </tbody>
        </table>
      </div>
    </main>
  </div>
</div>



<!-- Ajouter une boutique Modal start -->
<div class="modal fade" id="add_shop_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ajouter une boutique</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="add-shop-form" enctype="multipart/form-data">
        	<div class="row">
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Nom de la boutique</label>
		        		<input type="text" name="shop_name" class="form-control" placeholder="Entrer Nom de la boutique">
		        	</div>
        		</div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Nom de catégorie</label>
		        		<select class="form-control category_list" name="category_id">
		        			<option value="">Choisir une catégorie</option>
		        		</select>
		        	</div>
        		</div>
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Addresse</label>
		        		<input type="text" name="shop_address" class="form-control" placeholder="Entrer addresse de la boutique">
		        	</div>
        		</div>
				    <div class="col-12">
              <div class="form-group">
		        		<label>Contact Whatsapp</label>
		        		<input type="text" name="shop_contact_1" class="form-control" placeholder="Entrer le numero de whatsapp">
		        	</div>
              <div class="form-group">
		        		<label>Contact Mobile</label>
		        		<input type="text" name="shop_contact_2" class="form-control" placeholder="Entrer le numero de tel mobile">
		        	</div>
        		</div>
       		       		
        		<div class="col-12">
        			<div class="form-group">
		        		<label>Image de la boutique<small>(format: jpg, jpeg, png)</small></label>
		        		<input type="file" name="shop_image" class="form-control">
		        	</div>
        		</div>
                <input type="hidden" name="add_shop" value="1">
                <div class="col-12">
                    <button type="button" class="btn btn-primary add-shop">Ajouter une boutique</button>
                </div>
        	</div>
        	
        </form>
      </div>
    </div>
  </div>
</div>
<!--  Ajouter une boutique Modal end -->

<!-- Edit Boutique Modal start -->
<div class="modal fade" id="edit_shop_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Ajouter un produit</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <form id="edit-shop-form" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label>Nom de la boutique</label>
                            <input type="text" name="e_shop_name" class="form-control" placeholder="Entrer Nom de la boutique">
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label>Nom de catégorie</label>
                            <select class="form-control category_list" name="e_category_id">
                                <option value="">Choisir une catégorie</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label>Addresse</label>
                            <input type="text" name="e_shop_address" class="form-control" placeholder="Entrer addresse de la boutique">
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="form-group">
                            <label>Contact Whatsapp</label>
                            <input type="text" name="e_shop_contact_1" class="form-control" placeholder="Entrer le numero de whatsapp">
                        </div>
                        <div class="form-group">
                            <label>Contact Mobile</label>
                            <input type="text" name="e_shop_contact_2" class="form-control" placeholder="Entrer le numero de tel mobile">
                        </div>
                    </div>
                            
                    <div class="col-12">
                        <div class="form-group">
                            <label>Image de la boutique<small>(format: jpg, jpeg, png)</small></label>
                            <input type="file" name="e_shop_image" class="form-control">
                        </div>
                    </div>
                    
                    <input type="hidden" name="sid">
                    <input type="hidden" name="edit-shop" value="1">
                    <div class="col-12">
                        <button type="button" class="btn btn-primary submit-edit-shop">Editer une Boutique</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
<!-- Edit Product Modal end -->

<?php include_once("./templates/footer.php"); ?>



<script type="text/javascript" src="./js/boutiques.js"></script>