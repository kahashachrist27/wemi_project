<?php 
session_start();

if (file_exists("../../config/constants.php")) {
	require_once "../../config/constants.php";
}
if (file_exists("../config/constants.php")) {
	require_once "../config/constants.php";
}

class Shops
{
	
	private $con;
	private $bdd;

	function __construct()
	{
		include_once("Database.php");
		$db = new Database();
		$this->con = $db->connect();
		$this->bdd = $db->bdd;
	}

	public function getShops(){
		$q = $this->con->query("SELECT s.shop_id, s.shop_title, s.shop_address, s.shop_contact_1, s.shop_contact_2, s.shop_image, c.cat_shop_title, c.cat_shop_id FROM shops s  JOIN categories_shop c ON c.cat_shop_id = s.shop_cat ORDER BY s.shop_id DESC ");
		
		$shops = [];
		if ($q->num_rows > 0) {
			while($row = $q->fetch_assoc()){
				$shops[] = $row;
			}
			//return ['status'=> 202, 'message'=> $ar];
			$_DATA['shops'] = $shops;
		}
		
		$categories_shop = [];
		$q = $this->con->query("SELECT * FROM categories_shop");
		if ($q->num_rows > 0) {
			while($row = $q->fetch_assoc()){
				$categories_shop[] = $row;
			}
			//return ['status'=> 202, 'message'=> $ar];
			$_DATA['categories_shop'] = $categories_shop;
		}
        
		return ['status'=> 202, 'message'=> $_DATA];
	}

	public function addShop($shop_name,
		$category_id,
		$shop_address,
		$shop_contact_1,
		$shop_contact_2,
		$file){

		$fileName = $file['name'];
		$fileNameAr= explode(".", $fileName);
		$extension = end($fileNameAr);
		$ext = strtolower($extension);

		if ($ext == "jpg" || $ext == "jpeg" || $ext == "png") {
			
			//print_r($file['size']);

			if ($file['size'] > (1024 * 2)) {
				
				$uniqueImageName = time()."_".$file['name'];
				if (move_uploaded_file($file['tmp_name'], DOCUMENT_ROOT."shop_images/".$uniqueImageName)) {
					
					$str = "INSERT INTO shops SET  shop_title=?, shop_cat=?,   shop_address=?,   shop_contact_1=?,   shop_contact_2=?,   shop_image=? ";
					$req = $this->bdd->prepare($str);// on prepare la requete
         
        			$q = $req->execute(array( $shop_name, $category_id, $shop_address, $shop_contact_1, $shop_contact_2, $uniqueImageName ));// on exectute la reque 

					if ($q) {
						return ['status'=> 202, 'message'=> 'Boutique ajouté avec succès ..!'];
					}else{
						return ['status'=> 303, 'message'=> 'Échec de l\'exécution de la requête'];
					}

				}else{
					return ['status'=> 303, 'message'=> 'Échec du téléchargement de l\'image'];
				}

			}else{
				return ['status'=> 303, 'message'=> 'Grande image, taille maximale autorisée 2 Mo'];
			}

		}else{
			return ['status'=> 303, 'message'=> 'Format d\'image non valide [Formats valides: jpg, jpeg, png]'];
		}


	}
	//Fin add Shop

	//Edit Shop
	public function editShopWithImage($sid,
										$shop_name,
										$category_id,
										$shop_address,
										$shop_contact_1,
										$shop_contact_2,
										$file){



		$fileName = $file['name'];
		$fileNameAr= explode(".", $fileName);
		$extension = end($fileNameAr);
		$ext = strtolower($extension);

		if ($ext == "jpg" || $ext == "jpeg" || $ext == "png") {
			
			//print_r($file['size']);

			if ($file['size'] > (1024 * 2)) {
				
				$uniqueImageName = time()."_".$file['name'];
				if (move_uploaded_file($file['tmp_name'], DOCUMENT_ROOT."shop_images/".$uniqueImageName)) {
					
					$str = "UPDATE shops SET  shop_title=?, shop_cat=?,  shop_address=?,   shop_contact_1=?,   shop_contact_2=?,   shop_image=? WHERE shop_id = ?";
					$req = $this->bdd->prepare($str);// on prepare la requete
         
        			$q = $req->execute(array(  $shop_name, $category_id,  $shop_address  , $shop_contact_1,   $shop_contact_2,   $uniqueImageName,   $sid));// on exectute la reque 

					if ($q) {
						return ['status'=> 202, 'message'=> 'Boutique modifiée avec succès ..!'];
					}else{
						return ['status'=> 303, 'message'=> 'Échec de l\'exécution de la requête'];
					}

				}else{
					return ['status'=> 303, 'message'=> 'Échec du téléchargement de l\'image'];
				}

			}else{
				return ['status'=> 303, 'message'=> 'Grande image, taille maximale autorisée 2 Mo'];
			}

		}else{
			return ['status'=> 303, 'message'=> 'Format d\'image non valide [Formats valides: jpg, jpeg, png]'];
		}

	}

	public function editShopWithoutImage($sid,
										$shop_name,
										$category_id,
										$shop_address,
										$shop_contact_1,
										$shop_contact_2){

		if ($sid != null) {
			
			$str = "UPDATE shops SET  shop_title=?, shop_cat=?,  shop_address=?,   shop_contact_1=?,   shop_contact_2=?,   shop_image=? WHERE shop_id = ?";
					$req = $this->bdd->prepare($str);// on prepare la requete
         
        			$q = $req->execute(array( $shop_name, $category_id,  $shop_address  , $shop_contact_1,   $shop_contact_2,   $uniqueImageName,   $sid));// on exectute la reque 
        			/*var_dump($_SERVER);
				die();*/

			if ($q) {
				return ['status'=> 202, 'message'=> 'Shop updated Successfully'];
			}else{
				return ['status'=> 303, 'message'=> 'Failed to run query'];
			}
			
		}else{
			return ['status'=> 303, 'message'=> 'Identifiant de boutique non valide'];
		}
		
	}
	//Function pour supprimer une boutique
	public function deleteShop($sid = null){
		if ($sid != null) {
			$q = $this->con->query("DELETE FROM shops WHERE shop_id = '$sid'");
			if ($q) {
				return ['status'=> 202, 'message'=> 'Boutique retiré des stocks'];
			}else{
				return ['status'=> 202, 'message'=> 'Échec de l\'exécution de la requête'];
			}
			
		}else{
			return ['status'=> 303, 'message'=>'Identifiant de Boutique non valide'];
		}

	}
    //Function add category shop
	
	public function addCategory($name){
		$q = $this->con->query("SELECT * FROM categories_shop WHERE cat_shop_title = '$name' LIMIT 1");
		if ($q->num_rows > 0) {
			return ['status'=> 303, 'message'=> 'Category already exists'];
		}else{
			$q = $this->con->query("INSERT INTO categories_shop (cat_shop_title) VALUES ('$name')");
			if ($q) {
				return ['status'=> 202, 'message'=> 'New Category added Successfully'];
			}else{
				return ['status'=> 303, 'message'=> 'Failed to run query'];
			}
		}
	}

	public function getCategories(){
		$q = $this->con->query("SELECT * FROM categories_shop");
		$ar = [];
		if ($q->num_rows > 0) {
			while ($row = $q->fetch_assoc()) {
				$ar[] = $row;
			}
		}
		return ['status'=> 202, 'message'=> $ar];
	}
	//Mettre a jour la categorie
	public function updateCategory($post = null){
		extract($post);
		if (!empty($cat_shop_id) && !empty($e_cat_shop_title)) {
			$q = $this->con->query("UPDATE categories_shop SET e_cat_shop_title = '$e_cat_shop_title' WHERE cat_shop_id = '$cat_shop_id'");
			if ($q) {
				return ['status'=> 202, 'message'=> 'Catégorie mise à jour'];
			}else{
				return ['status'=> 202, 'message'=> 'Échec de l\'exécution de la requête'];
			}
			
		}else{
			return ['status'=> 303, 'message'=>'Identifiant de catégorie non valide'];
		}

	}
	//Supprimer categorie
	public function deleteCategory($cid = null){
		if ($cid != null) {
			$q = $this->con->query("DELETE FROM categories_shop WHERE cat_shop_id = '$cid'");
			if ($q) {
				return ['status'=> 202, 'message'=> 'Catégorie supprimée'];
			}else{
				return ['status'=> 202, 'message'=> 'Échec de l\'exécution de la requête'];
			}
			
		}else{
			return ['status'=> 303, 'message'=>'Identifiant de catégorie non valide'];
		}

	}


}
	
if (isset($_POST['GET_SHOP'])) {
	if (isset($_SESSION['admin_id'])) {
		$s = new shops();
		echo json_encode($s->getShops());
		exit();
	}
}


if (isset($_POST['add_shop'])) {

	extract($_POST);
	if (!empty($shop_name) 
	&& !empty($category_id)
	&& !empty($shop_address)
	&& !empty($shop_contact_1)
	&& !empty($shop_contact_2)
	&& !empty($_FILES['shop_image']['name'])) {
		

		$s = new shops();
		$result = $s->addshop($shop_name,
								$category_id,
								$shop_address,
								$shop_contact_1,
                                $shop_contact_2,
								$_FILES['shop_image']);
		
		// header("Content-type: application/json");
		echo json_encode($result);
		// http_response_code($result['status']);
		exit();


	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Champs vides']);
		exit();
	}

	
}


if (isset($_POST['edit-shop'])) {

	extract($_POST);
	if (!empty($sid)
	&& !empty($e_shop_name) 
	&& !empty($e_category_id)
	&& !empty($e_shop_address)
	&& !empty($e_shop_contact_1)
	&& !empty($e_shop_contact_2) ) {
		
		$s = new shops();

		if (isset($_FILES['e_shop_image']['name']) 
			&& !empty($_FILES['e_shop_image']['name'])) {
			$result = $s->editShopWithImage($sid,
								$e_shop_name,
								$e_category_id,
								$e_shop_address,
								$e_shop_contact_1,
								$e_shop_contact_2,
								$_FILES['e_shop_image']);
		}else{
			$result = $s->editShopWithoutImage($sid,
								$e_shop_name,
								$e_category_id,
								$e_shop_address,
								$e_shop_contact_1,
								$e_shop_contact_2);
		}

		echo json_encode($result);
		exit();


	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Champs vides']);
		exit();
	}



	
}


if (isset($_POST['DELETE_SHOP'])) {
	$s = new shops();
	if (isset($_SESSION['admin_id'])) {
		if(!empty($_POST['sid'])){
			$sid = $_POST['sid'];
			echo json_encode($s->deleteShop($sid));
			exit();
		}else{
			echo json_encode(['status'=> 303, 'message'=> 'Identifiant de Boutique non valide']);
			exit();
		}
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Session Invalide']);
	}


}
if (isset($_POST['add_category'])) {
	if (isset($_SESSION['admin_id'])) {
		$cat_shop_title = $_POST['cat_shop_title'];
		if (!empty($cat_shop_title)) {
			$p = new Shops();
			echo json_encode($p->addCategory($cat_shop_title));
		}else{
			echo json_encode(['status'=> 303, 'message'=> 'Champs vides']);
		}
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Erreur de session']);
	}
}

if (isset($_POST['GET_CATEGORIES'])) {
	$p = new Shops();
	echo json_encode($p->getCategories());
	exit();
	
}
//editer category
if (isset($_POST['edit_category'])) {
	if (!empty($_POST['cat_shop_id'])) {
		$p = new Shops();
		echo json_encode($p->updateCategory($_POST));
		exit();
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Détails invalides']);
		exit();
	}
}

if (isset($_POST['DELETE_CATEGORY'])) {
	if (!empty($_POST['cid'])) {
		$p = new Shops();
		echo json_encode($p->deleteCategory($_POST['cid']));
		exit();
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Détails invalides']);
		exit();
	}
}




?>