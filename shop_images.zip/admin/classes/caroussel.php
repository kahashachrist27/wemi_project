<?php 

if (file_exists("../../config/constants.php")) {
	require_once "../../config/constants.php";
}
if (file_exists("../config/constants.php")) {
	require_once "../config/constants.php";
}
class Caroussel
{
	
	private $con;
	private $bdd;

	function __construct()
	{
		include_once("Database.php");
		$db = new Database();
		$this->con = $db->connect();
		$this->bdd = $db->bdd;
	}

	public function getCaroussel(){
		$q = $this->con->query("SELECT caroussel_id,caroussel_title,caroussel_image,etat,brand_title caroussel_brand FROM caroussels,brands WHERE caroussels.brand_id=brands.brand_id UNION ALL SELECT caroussel_id,caroussel_title,caroussel_image,etat,'Aucune' caroussel_brand FROM caroussels WHERE brand_id=0;");
		
		$caroussels = [];
		if ($q->num_rows > 0) {
			while($row = $q->fetch_assoc()){
				$caroussels[] = $row;
			}
		}

		return $caroussels;
	}
public function getBrand_croussel(){
		$brands = [];
		$q = $this->con->query("SELECT * FROM brands");
		if ($q->num_rows > 0) {
			while($row = $q->fetch_assoc()){
				$brands[] = $row;
			}
			//return ['status'=> 202, 'message'=> $ar];
			//$_DATA['brands'] = $brands;
		}
		return $brands;
	}

	public function addCaroussel($caroussel_name,$file,$brand){


		$fileName = $file['name'];
		$fileNameAr= explode(".", $fileName);
		$extension = end($fileNameAr);
		$ext = strtolower($extension);

		if ($ext == "jpg" || $ext == "jpeg" || $ext == "png") {
			
			
			if ($file['size'] > (1024 * 3)) {
				
				$uniqueImageName = time()."_".$file['name'];
				if (move_uploaded_file($file['tmp_name'], DOCUMENT_ROOT."caroussel_images/".$uniqueImageName)) {
					
					$str = "INSERT INTO caroussels SET caroussel_title=?, caroussel_image=?, brand_id=? ";
					$req = $this->bdd->prepare($str);// on prepare la requete $', '$',$
					$q = $req->execute(array( $caroussel_name,  $uniqueImageName  ,   $brand));

					if ($q) {
						return ['status'=> 202, 'message'=> 'Caroussel ajouté avec succès ..!'];
					}else{
						return ['status'=> 303, 'message'=> 'Échec de l\'exécution de la requête'];
					}

				}else{
					return ['status'=> 303, 'message'=> 'Échec du téléchargement de l\'image'];
				}

			}else{
				return ['status'=> 303, 'message'=> 'Grande image, taille maximale autorisée 3 Mo'];
			}

		}else{
			return ['status'=> 303, 'message'=> 'Format d\'image non valide [Formats valides: jpg, jpeg, png]'];
		}


	}


	public function editCarousselWithImage($cid, $caroussel_name, $file,$brand){


		$fileName = $file['name'];
		$fileNameAr= explode(".", $fileName);
		$extension = end($fileNameAr);
		$ext = strtolower($extension);
		if ($ext == "jpg" || $ext == "jpeg" || $ext == "png") {
			
			//print_r($file['size']);

			if ($file['size'] > (1024 * 3)) {
				
				$uniqueImageName = time()."_".$file['name'];
				if (move_uploaded_file($file['tmp_name'], DOCUMENT_ROOT."caroussel_images/".$uniqueImageName)) {
					
					$str = "UPDATE caroussels SET caroussel_title=?, caroussel_image=?, brand_id=? WHERE caroussel_id=?";
					$req = $this->bdd->prepare($str);// on prepare la requete $', '$',$
					$q = $req->execute(array( $caroussel_name,  $uniqueImageName  ,   $brand, $cid));

					if ($q) {
						return ['status'=> 202, 'message'=>'Caroussel modifié avec succès ..!'];
					}else{
						return ['status'=> 303, 'message'=> 'Échec de l\'exécution de la requête'];
					}

				}else{
					return ['status'=> 303, 'message'=> 'Échec du téléchargement de l\'image'];
				}

			}else{
				return ['status'=> 303, 'message'=> 'Grande image, taille maximale autorisée 2 Mo'];
			}

		}else{
			return ['status'=> 303, 'message'=> 'Format d\'image non valide [Formats valides: jpg, jpeg, png]'];
		}

	}

	public function editCarousselWithoutImage($cid, $caroussel_name,$brand){

		if ($cid != null) {
			
			$str = "UPDATE caroussels SET caroussel_title=?, brand_id=? WHERE caroussel_id=?";
					$req = $this->bdd->prepare($str);// on prepare la requete $', '$',$
					$q = $req->execute(array( $caroussel_name, $brand, $cid));


			if ($q) {
				return ['status'=> 202, 'message'=> 'Caroussel Modifier avec success'];
			}else{
				return ['status'=> 303, 'message'=> 'Echec de l\'execution'];
			}
			
		}else{
			return ['status'=> 303, 'message'=> 'Identifiant de caroussel non valide'];
		}
		
	}


	public function deleteCaroussel($cid = null){
		if ($cid != null) {
			$q = $this->con->query("DELETE FROM Caroussels WHERE caroussel_id = '$cid'");
			if ($q) {
				return ['status'=> 202, 'message'=> 'Caroussel retiré'];
			}else{
				return ['status'=> 303, 'message'=> 'Échec de l\'exécution de la requête'];
			}
			
		}else{
			return ['status'=> 303, 'message'=>'Identifiant de Caroussel non valide'];
		}

	}


	public function updateEtatCaroussel($cid, $etat){
		if (!empty($cid)) {
			$q = $this->con->query("UPDATE caroussels SET etat = '$etat' WHERE caroussel_id = '$cid'");
			if ($q) {
				return ['status'=> 202, 'message'=> 'Etat mise à jour'];
			}else{
				return ['status'=> 303, 'message'=> 'Échec de l\'exécution de la requête'];
			}
			
		}else{
			return ['status'=> 303, 'message'=>'Identifiant du caroussel non valide'];
		}

	}

	

}



function get_caroussel(){
    if (isset($_SESSION['admin_id'])) {
		$p = new Caroussel();
		return $p->getCaroussel();
	}	
}
if (isset($_POST['GET_CAROUSSEL'])) {
	$p = new Caroussel();
	echo json_encode($p->getBrand_croussel());
	exit();
	
}

// renvoie un message d'information
    function flashInfo($status,$msg){
    	$type = "info";
    	if($status == 202){
    		$type = "success";
    	}elseif ($status == 303) {
    		$type = "danger";
    	}
?>
      <div class="col-md alert alert-<?= $type?> text-center" id='alert' style=''>
        <button type="button" class="close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h6><?= $msg?></h6>
      </div>
<?php
    }


  


if (isset($_POST['add_caroussel'])) {

	extract($_POST);
	if (!empty($e_caroussel_name) 
	&& !empty($_FILES['caroussel_image']['name'])) {
		

		$p = new Caroussel();
		$result = $p->addCaroussel($e_caroussel_name,
								$_FILES['caroussel_image'],$brand_id);

		flashInfo($result['status'], $result['message']);
		
	}else{
		flashInfo(303, 'Champs vides');
		
	}



	
}


if (isset($_POST['edit_caroussel'])) {

	extract($_POST);
	if (!empty($cid)
	&& !empty($e_caroussel_name) ) {
		
		$p = new Caroussel();

		if (isset($_FILES['e_caroussel_image']['name']) 
			&& !empty($_FILES['e_caroussel_image']['name'])) {
			$result = $p->editCarousselWithImage($cid,
								$e_caroussel_name,
								$_FILES['e_caroussel_image'],$e_brand_id);
		}else{
			$result = $p->editCarousselWithoutImage($cid,
								$e_caroussel_name,$e_brand_id);
		}

		flashInfo($result['status'], $result['message']);
		


	}else{
		flashInfo(303, 'Champs vides');
		
	}



	
}


if (isset($_POST['delete_Caroussel'])) {
	$p = new Caroussel();
	if (isset($_SESSION['admin_id'])) {
		if(!empty($_POST['cid'])){
			$cid = $_POST['cid'];
			$result = $p->deleteCAROUSSEL($cid);
			flashInfo($result['status'], $result['message']);
			
		}else{
			$result = ['status'=> 303, 'message'=> 'Identifiant de Caroussel non valide'];
			flashInfo($result['status'], $result['message']);
			
		}
	}else{
		$result = ['status'=> 303, 'message'=> 'Session Invalide'];
		flashInfo($result['status'], $result['message']);
	}


}

if (isset($_POST['active_etat_caroussel']) || isset($_POST['desactive_etat_caroussel'])) {
	if (!empty($_POST['cid'])) {
		extract($_POST);
		$etat = 0;
		if (isset($_POST['active_etat_caroussel'])){
			$etat = 1;
		}else{
			$etat = 0;
		}
		$p = new Caroussel();
		$result = $p->updateEtatCaroussel($cid, $etat);
		flashInfo($result['status'], $result['message']);
		
	}else{
		$result = ['status'=> 303, 'message'=> 'Détails invalides'];
		flashInfo($result['status'], $result['message']);
		
	}
}

?>