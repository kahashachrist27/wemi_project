<?php 
session_start();
/**
 * 
 */
class Credentials
{
	
	private $con;

	function __construct()
	{
		include_once("Database.php");
		$db = new Database();
		$this->con = $db->connect();
	}


	public function createAdminAccount($name, $email, $password, $typeAdmin){
		$q = $this->con->query("SELECT email FROM admin WHERE email = '$email'");
		if ($q->num_rows > 0) {
			return ['status'=> 303, 'message'=> 'Email already exists'];
		}else{
			$password = md5($password);
			$q = $this->con->query("INSERT INTO `admin`(`name`, `email`, `password`, `is_active`, `typeAdmin`) VALUES ('$name','$email','$password','0','$typeAdmin')");
			if ($q) {
				return ['status'=> 202, 'message'=> 'L\'administrateur a été créé avec succès'];
			}

		}
	}

	public function loginAdmin($email, $password){
		$password=md5($password);
		$q = $this->con->query("SELECT * FROM admin WHERE email = '$email' And password='$password' LIMIT 1");
		if ($q->num_rows > 0) {
			$row = $q->fetch_assoc();
			if ($row) {
				$_SESSION['admin_name'] = $row['name'];
				$_SESSION['admin_id'] = $row['id'];
				$_SESSION['typeAdmin'] = $row['typeAdmin'];
				return ['status'=> 202, 'message'=> 'Login Successful'];
			}else{
				return ['status'=> 303, 'message'=> 'Login Fail'];
			}
		}else{
			return ['status'=> 303, 'message'=> 'Compte pas encore créé avec cet e-mail'];
		}
	}

}

//$c = new Credentials();
//$c->createAdminAccount("Rizwan", "rizwan@gmail.com", "12345");

//PRINT_R($c->loginAdmin("rizwan@gmail.com", "12345"));

if (isset($_POST['admin_register'])) {
	extract($_POST);
	if (!empty($name) && !empty($email) && !empty($password) && !empty($cpassword) && !empty($typeAdmin)) {
		if ($password == $cpassword) {
			$c = new Credentials();
			$result = $c->createAdminAccount($name, $email, $password, $typeAdmin);
			echo json_encode($result);
			exit();
		}else{
			echo json_encode(['status'=> 303, 'message'=> 'Non concordance des mots de passe']);
			exit();
		}
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Champs vides']);
		exit();
	}
}

if (isset($_POST['admin_login'])) {
	extract($_POST);
	if (!empty($email) && !empty($password)) {
		$c = new Credentials();
		$result = $c->loginAdmin($email, $password);
		echo json_encode($result);
		exit();
	}else{
		echo json_encode(['status'=> 303, 'message'=> 'Champs vides']);
		exit();
	}
}


?>