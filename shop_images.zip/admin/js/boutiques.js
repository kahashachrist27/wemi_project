$(document).ready(function(){

	var shopList;

	function getShops(){
		$.ajax({
			url : '../admin/classes/Boutiques.php',
			method : 'POST',
			data : {GET_SHOP:1},
			success : function(response){
				//console.log(response);
				var resp = $.parseJSON(response);
				if (resp.status == 202) {

					var shopHTML = '';

					shopList = resp.message.shops;

					if (shopList) {
						$.each(resp.message.shops, function(index, value){

							shopHTML += '<tr>'+
								              '<td>'+''+'</td>'+
								              '<td>'+ value.shop_title +'</td>'+
								              '<td><img width="60" height="60" src="../shop_images/'+value.shop_image+'"></td>'+
								              '<td>'+ value.cat_shop_title +'</td>'+
								              '<td>'+ value.shop_address +'</td>'+
								              '<td>'+ value.shop_contact_1 +'</td>'+
                                              '<td>'+ value.shop_contact_2 +'</td>'+
								              '<td><a class="btn btn-sm btn-info edit-shop" style="color:#fff;"><span style="display:none;">'+JSON.stringify(value)+'</span><i class="fas fa-pencil-alt"></i></a>&nbsp;<a sid="'+value.shop_id+'" class="btn btn-sm btn-danger delete-shop" style="color:#fff;"><i class="fas fa-trash-alt"></i></a></td>'+
								            '</tr>';
						});

						$("#shop_list").html(shopHTML);
					}

					var catSelectHTML = '<option value="">Selectionnez categories </option>';
					$.each(resp.message.categories_shop, function(index, value){

						catSelectHTML += '<option value="'+ value.cat_shop_id +'">'+ value.cat_shop_title +'</option>';

					});
					$(".category_list").html(catSelectHTML);

				}
			}

		});
	}
	
	function getShop(){
		$.ajax({
			url : '../admin/classes/Products.php',
			method : 'POST',
			data : {GET_SHOP:1},
			success : function(response){
				//console.log(response);
				var resp = $.parseJSON(response);

				var shopSelectHTML = '';

				$.each(resp.message, function(index, value){
					shopSelectHTML += '<tr>'+
									'<td></td>'+
									'<td>'+ value.shop_title +'</td>'+
									'<td><a class="btn btn-sm btn-info edit-brand"><span style="display:none;">'+JSON.stringify(value)+'</span><i class="fas fa-pencil-alt"></i></a>&nbsp;<a bid="'+value.shop_id+'" class="btn btn-sm btn-danger delete-brand"><i class="fas fa-trash-alt"></i></a></td>'+
								'</tr>';
				});

				$("#shop_list").html(shopSelectHTML);

			}
		})
	}
	getShops();

	$(".add-shop").on("click", function(){
		$.ajax({

			url : '../admin/classes/Boutiques.php',
			method : 'POST',
			data : new FormData($("#add-shop-form")[0]),
			contentType : false,
			cache : false,
			processData : false,
			success : function(response){
				console.log(response);
				var resp = JSON.parse(response);
				// var resp = JSON.parse(response);
				if (resp.status == 202) {
					alert(resp.message);
					$("#add-shop-form").trigger("reset");
					$("#add_shop_modal").modal('hide');
					// getshops();
					location.reload();
				}else if(resp.status == 303){
					alert(resp.message);
				}
				
			}
       
		});

	});


	$(document.body).on('click', '.edit-shop', function(){

		//console.log($(this).find('span').text());

		var shop = $.parseJSON($.trim($(this).find('span').text()));
		console.log(shop);

		$("input[name='e_shop_name']").val(shop.shop_title);
		$("select[name='e_category_id']").val(shop.cat_shop_id);
        $("input[name='e_shop_address']").val(shop.shop_address);
		$("input[name='e_shop_contact_1']").val(shop.shop_contact_1);
        $("input[name='e_shop_contact_2']").val(shop.shop_contact_2);
		$("input[name='e_shop_image']").siblings("img").attr("src", "../shop_images/"+shop.shop_image);
		$("input[name='sid']").val(shop.shop_id);
		$("#edit_shop_modal").modal('show');

	});

	$(".submit-edit-shop").on('click', function(){

		$.ajax({

			url : '../admin/classes/Boutiques.php',
			method : 'POST',
			data : new FormData($("#edit-shop-form")[0]),
			contentType : false,
			cache : false,
			processData : false,
			success : function(response){
				// console.log(response);
				var resp = $.parseJSON(response);
				if (resp.status == 202) {
					$("#edit-shop-form").trigger("reset");
					$("#edit_shop_modal").modal('hide');
					getShops();
					location.reload();
					//alert(resp.messag);
				}else if(resp.status == 303){
					alert(resp.message);
				}
			}

		});


	});

	$(document.body).on('click', '.delete-shop', function(){

		var sid = $(this).attr('sid');
		if (confirm("Etes-vous sur de vouloir supprimer cet element ?")) {
			$.ajax({

				url : '../admin/classes/Boutiques.php',
				method : 'POST',
				data : {DELETE_SHOP: 1, sid:sid},
				success : function(response){
					console.log(response);
					var resp = $.parseJSON(response);
					if (resp.status == 202) {
						getShops();
						location.reload();
					}else if (resp.status == 303) {
						alert(resp.message);
					}
				}

			});
		}else{
			alert('Cancelled');
		}
		

	});

});