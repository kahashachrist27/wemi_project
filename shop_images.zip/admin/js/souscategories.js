$(document).ready(function(){

	getSousCategories();
	
	function getSousCategories(){
		$.ajax({
			url : '../admin/classes/Products.php',
			method : 'POST',
			data : {GET_SOUS_CATEGORIES:1},
			success : function(response){
				console.log(response);
				var resp = $.parseJSON(response);

				var brandHTML = '';

				$.each(resp.message, function(index, value){
					brandHTML += '<tr>'+
									'<td></td>'+
									'<td>'+ value.cat_title +'</td>'+
									'<td><a class="btn btn-sm btn-info edit-sous_category"><span style="display:none;">'+JSON.stringify(value)+'</span><i class="fas fa-pencil-alt"></i></a>&nbsp;<a cid="'+value.cat_id+'" class="btn btn-sm btn-danger delete-sous_category"><i class="fas fa-trash-alt"></i></a></td>'+
								'</tr>';
				});

				$("#sous_category_list").html(brandHTML);

			}
		})
		
	}

	$(".add-sous_category").on("click", function(){

		$.ajax({
			url : '../admin/classes/Products.php',
			method : 'POST',
			data : $("#add-sous_category-form").serialize(),
			success : function(response){
				//console.log(response)
				var resp = $.parseJSON(response);
				if (resp.status == 202) {
					getSousCategories();
					alert(resp.message);
					
				}else if(resp.status == 303){
					alert(resp.message);
					
				}
				//$("#add_sous_category_modal").modal('hide');
				location.reload();
			}
		})

	});

	$(document.body).on("click", ".edit-sous_category", function(){

		var cat = $.parseJSON($.trim($(this).children("span").html()));
		$("input[name='e_cat_title']").val(cat.cat_title);
		$("input[name='cat_id']").val(cat.cat_id);

		$("#edit_sous_category_modal").modal('show');

		

	});

	$(".edit-sous_category-btn").on('click', function(){

		$.ajax({
			url : '../admin/classes/Products.php',
			method : 'POST',
			data : $("#edit-sous_category-form").serialize(),
			success : function(response){
				var resp = $.parseJSON(response);
				if (resp.status == 202) {
					getSousCategories();
					alert(resp.message);
				}else if(resp.status == 303){
					alert(resp.message);
				}
				$("#edit_sous_category_modal").modal('hide');
			}
		})

	});

	$(document.body).on('click', '.delete-sous_category', function(){

		var cid = $(this).attr('cid');
		

		if (confirm("Are you sure to delete this sous_category")) {
			$.ajax({
				url : '../admin/classes/Products.php',
				method : 'POST',
				data : {DELETE_sous_category:1, cid:cid},
				success : function(response){
					var resp = $.parseJSON(response);
					if (resp.status == 202) {
						alert(resp.message);
						getSousCategories();
					}else if(resp.status == 303){
						alert(resp.message);
					}
				}
			})
		}else{
			alert('Cancelled');
		}

		

	});

});