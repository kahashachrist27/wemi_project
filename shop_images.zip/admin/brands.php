<?php session_start(); ?>
<?php include_once("./templates/top.php"); ?>
<?php include_once("./templates/navbar.php"); ?>
<div class="container-fluid">
  <div class="row">
    
    <?php include "./templates/sidebar.php"; ?>

      <div class="row">
        <div class="col-10">
          <h2>Liste de Marques</h2>
        </div>
        <div class="col-2">
          <a href="#" data-toggle="modal" data-target="#add_brand_modal" class="btn btn-primary btn-sm">Ajouter une marque</a>
        </div>
      </div>
      
      <div class="table-responsive">
        <table class="table table-striped table-sm">
          <thead>
            <tr>
              <th>#</th>
              <th>Nom de la marque</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody id="brand_list">
            
          </tbody>
        </table>
      </div>
    </main>
  </div>
</div>



<!-- Ajouter une boutique Modal start -->
<div class="modal fade" id="add_brand_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ajouter une boutique</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        <form id="add-brand-form" enctype="multipart/form-data">
          <div class="row">
            <div class="col-12">
              <div class="form-group">
                <label>Nom de la boutique</label>
                <input type="text" name="shop_name" class="form-control" placeholder="Entrer Nom de la boutique">
              </div>
            </div>
            <div class="col-12">
            
                <input type="hidden" name="add_brand" value="1">
                <div class="col-12">
                    <button type="button" class="btn btn-primary add-brand">Ajouter une boutique</button>
                </div>
          </div>
          
        </form>
      </div>
    </div>
  </div>
</div>
<!--  Ajouter une boutique Modal end -->

<!-- Edit Boutique Modal start -->
<div class="modal fade" id="edit_shop_modal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
        <div class="modal-header">
            <h5 class="modal-title" id="exampleModalLabel">Editer une marque</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
            </button>
        </div>
        <div class="modal-body">
            <form id="edit-brand-form" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-12">
                        <div class="form-group">
                            <label>Nom de la Marque</label>
                            <input type="text" name="e_shop_name" class="form-control" placeholder="Entrer Nom de la boutique">
                        </div>
                    </div>
                    
                    <input type="hidden" name="sid">
                    <input type="hidden" name="edit-brand" value="1">
                    <div class="col-12">
                        <button type="button" class="btn btn-primary submit-edit-brand">Mettre a jour</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
</div>
<!-- Edit Product Modal end -->

<?php include_once("./templates/footer.php"); ?>



<script type="text/javascript" src="./js/brands.js"></script>