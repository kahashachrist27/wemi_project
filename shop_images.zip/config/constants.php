<?php

define('HOST', 'localhost');
define('USER', 'root');
define('PASSWORD', '');
define('DATABASE_NAME', 'wemi_project_db');

define('CURRENCY', '$');
define('WEB_SITE_NAME', 'wemiShop');
define('LIMIT_PAR_PAGE', 9);
define("ADDR", 'http://localhost/');
define("WEBROOT", str_replace('index.php','' , $_SERVER['SCRIPT_NAME']));

$REQUEST_URI = $_SERVER['REQUEST_URI'];
$tab_REQUEST_URI = explode("/", $REQUEST_URI);
$root = "";
if ($tab_REQUEST_URI[1] == "shop_mwisa") {
	
	if(HOST != "wemishop.com"){
        $root = $tab_REQUEST_URI[1]."/";
    }
}

define("BASE_URL", ADDR.$root);

define("DOCUMENT_ROOT", $_SERVER['DOCUMENT_ROOT']."/".$root);


?>