
function shareTrackSocial(social,id,info_comp_url) {
	// Social 1: Facebook
	// Social 2: Twitter
	// Social 3: Google+
	// Social 4: Pinterest
	// Social 5: Mail
	
	//variable necessaire
	
	// var url = encodeURIComponent($("#song-url"+id).attr('href'));
	 var title = encodeURIComponent($("#product-title").text());
	var art = encodeURIComponent($("#product-art").attr('src'));
	
	// var url= window.location.href;
	// var pageName= window.location.pathname;
	//var AdressSite =$('.AdressSite').val();
	//var pageName= document.title;
	var url= encodeURIComponent(info_comp_url);
	
	if(social == 1) {
		window.open("https://www.facebook.com/sharer/sharer.php?u="+url, "", "width=500, height=250");
	} else if(social == 2) {
		window.open("https://twitter.com/intent/tweet?text="+title+"&url="+url, "", "width=500, height=250");
	} else if(social == 3) {
		window.open("https://plus.google.com/share?url="+url, "", "width=500, height=250");
	} else if(social == 4) {
		window.open("https://pinterest.com/pin/create/button/?url="+url+"&description="+title+"&media="+art, "", "width=500, height=250");
	} else if(social == 5) {
		window.open("mailto:?Subject="+title+"&body="+title+" - "+url, "_self");
	}
	
	//alert (title);
};