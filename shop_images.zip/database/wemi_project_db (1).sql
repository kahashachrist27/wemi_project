-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 16 fév. 2024 à 10:43
-- Version du serveur :  10.4.10-MariaDB
-- Version de PHP :  7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `wemi_project_db`
--

-- --------------------------------------------------------

--
-- Structure de la table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL,
  `is_active` enum('0','1') NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `admin`
--

INSERT INTO `admin` (`id`, `name`, `email`, `password`, `is_active`) VALUES
(8, 'toto', 'toto@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '0'),
(9, 'Dieu Merci Kwiravusa', 'kwiravusadieumerci@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '0'),
(10, 'tito', 'tito@gmail.com', '1234', '0'),
(11, 'tito', 'titoti@gmail.com', 'e807f1fcf82d132f9bb018ca6738a19f', '0'),
(12, 'spin', 'spin@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '0');

-- --------------------------------------------------------

--
-- Structure de la table `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `brand_id` int(11) NOT NULL AUTO_INCREMENT,
  `brand_title` text NOT NULL,
  PRIMARY KEY (`brand_id`)
) ENGINE=InnoDB AUTO_INCREMENT=48 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `brands`
--

INSERT INTO `brands` (`brand_id`, `brand_title`) VALUES
(2, 'Samsung'),
(3, 'Apple'),
(6, 'Itel'),
(7, 'Infinix'),
(8, 'Tecno'),
(9, 'Huawei'),
(10, 'Xiaomi'),
(12, 'Oppo'),
(15, 'Nivea'),
(17, 'Versace'),
(28, 'Dan Trade'),
(32, 'Epice'),
(33, 'Atelog'),
(34, 'Fremily'),
(35, 'Natalie'),
(36, 'Alsi'),
(37, 'muyiStore'),
(38, 'Shoes'),
(39, 'Habillement'),
(40, 'Timberland'),
(41, 'Louis Viton'),
(42, 'Gucci'),
(43, 'Fendi'),
(44, 'Christian Dior'),
(45, 'Goofle'),
(46, 'Converse'),
(47, 'Warrior');

-- --------------------------------------------------------

--
-- Structure de la table `caroussels`
--

DROP TABLE IF EXISTS `caroussels`;
CREATE TABLE IF NOT EXISTS `caroussels` (
  `caroussel_id` int(11) NOT NULL AUTO_INCREMENT,
  `caroussel_title` varchar(255) NOT NULL,
  `caroussel_image` varchar(255) NOT NULL,
  `etat` int(11) NOT NULL DEFAULT 1,
  `brand_id` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`caroussel_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `caroussels`
--

INSERT INTO `caroussels` (`caroussel_id`, `caroussel_title`, `caroussel_image`, `etat`, `brand_id`) VALUES
(1, 'tout ce que vous trouvez dans nos muyiStore est aussi en ligne sur muyiSphere', '1621670885_muyiStore.jpg', 1, 37),
(3, 'NATALIE SAAMOJA', '1619212063_natalie.jpg', 0, 35),
(4, 'FREMILY BABY MODA', '1620936046_BabyModda.jpg', 1, 34),
(5, 'Alsi Fashion Galerie Sion', '1619211845_AlciFashion.jpg', 0, 36),
(6, 'Atelog-Atelier du logiciel', '1619098294_atelog-muyisphere copy.PNG', 1, 33),
(8, 'Dan Trade', '1621670931_DanTrade.jpg', 0, 28),
(11, 'cc', '1622874783_IMG-20210513-WA0003.jpg', 0, 37);

-- --------------------------------------------------------

--
-- Structure de la table `cart`
--

DROP TABLE IF EXISTS `cart`;
CREATE TABLE IF NOT EXISTS `cart` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `p_id` int(11) NOT NULL,
  `ip_add` varchar(250) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `qty` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=41 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `cart`
--

INSERT INTO `cart` (`id`, `p_id`, `ip_add`, `user_id`, `qty`) VALUES
(3, 7, '::1', 1, 1),
(17, 84, '::1', 4, 1),
(18, 89, '127.0.0.1', -1, 1),
(19, 86, '::1', 4, 1),
(21, 85, '::1', 1, 1),
(22, 133, '::1', 5, 1),
(24, 122, '::1', 6, 2),
(25, 134, '::1', 5, 1),
(26, 122, '::1', 5, 2),
(27, 120, '::1', 5, 1),
(28, 118, '::1', 5, 1),
(29, 108, '::1', 5, 1),
(38, 163, '::1', -1, 1),
(39, 176, '::1', -1, 1),
(40, 175, '::1', -1, 1);

-- --------------------------------------------------------

--
-- Structure de la table `categories`
--

DROP TABLE IF EXISTS `categories`;
CREATE TABLE IF NOT EXISTS `categories` (
  `cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_title` text NOT NULL,
  PRIMARY KEY (`cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`) VALUES
(12, 'Mobiles, Tablettes & SmartPhone'),
(13, 'TV, Video et Song'),
(14, 'Ordinateurs et Bureautique'),
(15, 'Hygiene, Beaute et Parfumerie'),
(16, 'Habillements pour Dames'),
(17, 'Mode Masculine'),
(18, 'Home, Kitchen & Pets'),
(19, 'Electronic, Electricite et ElectroMenger'),
(20, 'Food Market'),
(22, 'Kids Fashion'),
(23, 'Logiciels,Sites web et Applications'),
(24, 'Environnement'),
(26, 'Fashion Style'),
(27, 'Mixte');

-- --------------------------------------------------------

--
-- Structure de la table `categories_shop`
--

DROP TABLE IF EXISTS `categories_shop`;
CREATE TABLE IF NOT EXISTS `categories_shop` (
  `cat_shop_id` int(11) NOT NULL AUTO_INCREMENT,
  `cat_shop_title` varchar(40) NOT NULL,
  PRIMARY KEY (`cat_shop_id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `categories_shop`
--

INSERT INTO `categories_shop` (`cat_shop_id`, `cat_shop_title`) VALUES
(1, 'Vetements'),
(2, 'Site Web'),
(3, 'Boulangerie'),
(4, 'Patisserie'),
(7, 'securite'),
(10, 'Chuma'),
(8, 'Shoes'),
(9, 'Ingénierie'),
(11, 'Sosa');

-- --------------------------------------------------------

--
-- Structure de la table `orders`
--

DROP TABLE IF EXISTS `orders`;
CREATE TABLE IF NOT EXISTS `orders` (
  `order_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `qty` int(11) NOT NULL,
  `trx_id` varchar(255) NOT NULL,
  `p_status` varchar(20) NOT NULL,
  PRIMARY KEY (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `orders`
--

INSERT INTO `orders` (`order_id`, `user_id`, `product_id`, `qty`, `trx_id`, `p_status`) VALUES
(1, 1, 1, 1, '9L434522M7706801A', 'Completed'),
(2, 1, 2, 1, '9L434522M7706801A', 'Completed'),
(3, 1, 3, 1, '9L434522M7706801A', 'Completed'),
(4, 1, 1, 1, '8AT7125245323433N', 'Completed');

-- --------------------------------------------------------

--
-- Structure de la table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `product_id` int(11) NOT NULL AUTO_INCREMENT,
  `product_shop` int(11) NOT NULL,
  `product_cat` int(11) NOT NULL,
  `product_sous_cat` int(11) NOT NULL,
  `product_brand` int(11) NOT NULL,
  `product_title` varchar(255) NOT NULL,
  `product_price` int(11) NOT NULL,
  `product_qty` int(11) NOT NULL,
  `product_desc` text NOT NULL,
  `product_image` text NOT NULL,
  `product_keywords` text NOT NULL,
  PRIMARY KEY (`product_id`),
  KEY `fk_product_cat` (`product_cat`),
  KEY `fk_product_brand` (`product_brand`)
) ENGINE=InnoDB AUTO_INCREMENT=177 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `products`
--

INSERT INTO `products` (`product_id`, `product_shop`, `product_cat`, `product_sous_cat`, `product_brand`, `product_title`, `product_price`, `product_qty`, `product_desc`, `product_image`, `product_keywords`) VALUES
(100, 0, 12, 53, 8, 'Tecno Spark5 Pro', 150, 100, 'Stockage 128 gb\r\nPour vous le procurer, contactez nous au +243892465600\r\n', '1619328550_Tecno_Spark5Pro.jpg', 'Tecno, Android, Spark'),
(101, 0, 12, 1, 28, 'SQ3310s', 19, 100, 'Pour vous le procurer, contactez nous  sur WhatsApp au +243892465600', '1619210667_SQ3310s.jpg', 'SQ,Mobiles, Dan Trade'),
(102, 0, 12, 53, 7, 'Infinix Smart5 Pro', 100, 100, 'Pour vous le procurer, contactez nous au +243892465600', '1619328064_Infinix_Smart5_Pro.jpg', 'infinix, Android, Smart'),
(103, 0, 12, 53, 6, 'Itel S16 Pro', 95, 100, 'Pour vous le procurer, contactez nous au +243892465600', '1619605073_itel_s16Pro.jpg', 'Itel, Android, S16'),
(104, 0, 12, 53, 12, 'Oppo A73', 250, 100, 'Pour vous le procurer, contactez nous au +243892465600', '1619211484_A73 5G-navigation-Black-v2.png', 'Oppo, Android, A73'),
(105, 0, 13, 29, 2, 'SAMSUNG TV LED 4K UHD - 65\" (163 cm) - Ecran incurve', 2000, 100, 'Taille d ecran : 138 cm (55\")\r\nRetroeclairage par LED - assombrissement UHD\r\nPour vous le procurer, contactez nous au +243892465600\r\nFormat d affichage : 4K UHD (2160p)\r\nResolution : 3840 x 2160\r\nTechnologie HDR : HDR 10+, Hybrid Log-Gamma (HLG)\r\nTuner TV numerique : DVB-C, DVB-T2\r\nAmeliorations d image : Digital Clean View, Mega Contrast, accentuation du contraste, Reglage automatique de la profondeur, PurColor, Amplificateur de jeu, Affichage Crystal\r\nTeleviseur Led\r\n\r\nPour vous le procurer, contactez nous au +243892465600', '1619255074_samsung-tv-led-4k.jpg', 'Samsung, Televiseur, Ecran incurve'),
(106, 0, 14, 12, 9, 'HUAWEI MateBook X', 2000, 100, 'Processeur : Intel Core i7 (10gen) 10510U / 1.8 GHz\r\nRAM : 16 Go (la mÃ©moire fournie est soudee)\r\nPour vous le procurer, contactez nous au +243892465600\r\nResolution : 3000 x 2000\r\nStockage principal : 1 To SSD PCIe - NVM Express (NVMe)\r\nProcesseur graphique : NVIDIA GeForce MX250 / Intel UHD Graphics 620\r\nGarantie  : 2 ans\r\nSysteme d exploitation : Windows 10 Edition Familiale 64 bits\r\nOrdinateur Portable\r\nPour vous le procurer, contactez nous au +243892465600', '1619255711_Mateabook_Pro.jpg', 'Huawei, Laptop,ordinateur'),
(107, 0, 15, 46, 15, 'Nivea Men', 20, 100, 'Get your favorite NIVEA products at any of our muyiStore\r\nPour vous le procurer, contactez nous au +243892465600', '1621672029_nivea-body-care.jpg', 'Nivea, lait de BeautÃ©, Toilette'),
(108, 0, 16, 22, 28, 'Ceyo Red Wedges Slipper For Women', 25, 100, 'Brand: CEYO\r\nStyle: Wedge\r\nHeels: 2 Inches\r\nSize: All\r\nColor: All\r\nPour vous le procurer, contactez nous au +243892465600', '1619259106_ceyo.jpg', 'Ceyo, Babouche, Dame'),
(109, 0, 17, 22, 17, 'Versace Shoes', 50, 100, 'Pantoufle de luxe pour Homme. Pour vous le procurer, contactez nous au +243892465600', '1619260257_Versace_shoes.jpg', 'soulier, Versce, Home'),
(110, 0, 18, 57, 37, 'Leaving Room ', 500, 100, 'These tables are not unique and elegant but ultra strength\r\nPour vous le procurer, contactez nous au +243892465600', '1619261389_HightLevel.jpg', 'salon, royal, luxe'),
(111, 0, 19, 65, 37, 'KingMak KM5800DXE', 185, 100, 'Generateur King Max 5800 avec demarreur\r\nProcurez vous ce generateur en nous contactant au +2432465600', '1619262760_King_Max5800.jpg', 'Generateur, Electricite, '),
(112, 0, 19, 65, 37, 'KingMak KM5500ox', 170, 100, 'Generateur KM5500ox sans demarreur\r\nPour vos achats , contacter nous au +243892465600', '1619263137_King_Max5500.jpg', 'KingMax, KM5500ox'),
(113, 0, 20, 66, 32, 'Epice pour Cuisine', 5, 100, 'Pour une bonne cuisine, procurez vous vos epices en nous contactant au +2438965600', '1619264672_epices.jpeg', 'Nutrition, Epice, Cuisine'),
(115, 0, 23, 8, 33, 'Atelier du Logiciel', 500, 100, 'Conception et developpement des logiciels, site web et base de donnees, application mobile, logiciels de gestion...', '1619268559_atelog.png', 'Atelog,logiciel, Applications'),
(116, 0, 18, 59, 37, 'Tefal Super Cookware Set', 20, 100, 'Pour vous procurer une batterie de cuisine rendez vous dans notre muyiStore d ustensiles ou nous contacter au +243892465600', '1619269934_louche.jpg', 'Ustensile, cuisine, casseroles'),
(117, 0, 18, 63, 35, 'Tabletop MakeUp Mirror', 50, 100, 'Luxfurni Vanity Table MakeUp', '1619271196_Decor.jpg', 'Mirrors, Home DÃ©cor,luxury'),
(118, 0, 16, 23, 36, 'Pagne Super Wax', 150, 100, 'Super Wax, un pagne de hight auqlity. Pour tout achat, contactez nous au +243892465600', '1619271592_SuperWax.jpg', 'Super Wax, Pagne, vetement'),
(119, 0, 12, 53, 10, 'Xiaomi mi 11', 1000, 100, 'Taille de la diagonale : 6.81\r\nResolution du capteur : 108 megapixels\r\nCapacite de la batterie : 4600 mAh\r\nCapacite de la memoire interne : 256 Go\r\n8 coeurs\r\nRAM : 8 Go - LPDDR5 SDRAM\r\nGeneration a haut debit mobile : 5G\r\nSmartphone\r\n Pour tout achat, contactez nous au +243892465600', '1619272014_Mi11_HorizonBlue.jpg', 'xiaomi, android, mi11'),
(120, 0, 12, 54, 3, 'APPLE iPhone 12 Pro Max 512Go', 1700, 100, 'Taille de la diagonale : 6.7\r\nResolution du capteur : 12 megapixels\r\nCapacite de la memoire interne : 512 Go\r\n6 coeurs\r\nGeneration  haut debit mobile : 5G\r\nProtection : Revetement oleophobe antitrace, Ceramic Shield\r\nSysteme dexploitation : iOS 14\r\nPour tout achat, contactez nous au +243892465600', '1619327622_iphone12Pro_Max.jpg', 'iphone, ios, Smart Phone'),
(121, 0, 14, 12, 9, 'PC Huawei MateBook X Pro', 1700, 100, '\r\nPour tout achat, contactez nous au +243892465600', '1619274120_huawei-matebook.jpg', 'huawei, MateBook'),
(122, 2, 14, 12, 3, 'MacBook Pro 16\"', 3000, 100, 'Designed for those who defy limits and change the world, the 16-inch MacBook Pro is by far the most powerful notebook we have ever made. With an immersive Retina display, superfast processors, advanced graphics, the largest battery capacity ever in a MacBook Pro, Magic Keyboard, and massive storage, it is the ultimate pro notebook for the ultimate user.', '1619275838_macbookP.jpg', 'Mac, Ordinateur, Apple'),
(123, 1, 19, 10, 28, 'Veger Power Bank 25000mAh', 10, 100, 'Contactez nous sur WhatsApp au +243892465600 pour vous procurer Un Power Bank \r\nCapacity: 25000mAh\r\nNumber of charging Ports: 2\r\nCompatibleDevices: multiple\r\nOutPut1: 5V/1A I Output2: 5V/2A', '1619330484_Veger_PowerBank.jpg', 'Veger, power Bank, Accessoire'),
(125, 6, 12, 53, 7, 'Infinix HOT10', 110, 100, 'Infinix Hot 10 est un merveilleux reprÃ©sentant des tÃ©lÃ©phones d entrÃ©e de gamme. Il vous ravira avec un beau grand Ã©cran, un design sympa et ergonomique et un poids faible. Les photos sont bonnes pour ce prix. Ce qui est impressionnant est sa grande batterie, qui assure plus de deux jours dâ€™autonomie.\r\n\r\nLe smartphone convient aux utilisateurs sans trop d exigences qui souhaitent disposer d un ensemble de fonctionnalitÃ©s pratiques Ã  petit prix.\r\nPour tout contact, nous sommes au +243892465600', '1619604549_INFINIX_HOT10.jpg', 'Infinix, Hot10, Android'),
(127, 4, 12, 1, 28, 'SICCOO M6', 19, 100, 'Pour vous le procurer ce produit, contactez nous  sur WhatsApp au +243892465600', '1621669547_SiccooM6.jpg', 'Siccoo, M6, tÃ©lÃ©phone'),
(128, 0, 12, 1, 28, 'SICCOO M7', 16, 100, 'Pour vous le procurer ce produit, contactez nous  sur WhatsApp au +243892465600', '1621669632_SiccooM7.jpg', 'Siccoo, M7, tÃ©lÃ©phone'),
(129, 0, 12, 1, 28, 'SICCOO M2plus', 16, 100, 'Pour vous le procurer ce produit, contactez nous  sur WhatsApp au +243892465600', '1621669829_SiccooM2PLUS.jpg', 'Siccoo, M2Plus, tÃ©lÃ©phone'),
(130, 0, 16, 15, 35, 'TED BAKER chaussure Dame', 200, 100, 'Pour vous procurez ce produit, priÃ¨re nous contacter sur WhatsApp au +243892465600', '1621671745_TedBaker.jpg', 'Chaussure dame, Chaussure de luxe, Ted Bake'),
(131, 0, 16, 15, 35, 'TED BAKER de luxe', 200, 100, 'Pour vous procurez ce produit, priÃ¨re nous contacter sur WhatsApp au +243892465600', '1621671833_TBred.jpg', 'Chaussure dame, Chaussure de luxe, Ted Bake'),
(132, 0, 22, 18, 34, 'Versace pour Fillettes', 35, 100, 'Pour vous procurez ce produit, contacter nous sur WhatsApp au +243892465600', '1621673458_FremiV.jpg', 'Versace, kids fashion, habillement enfant'),
(133, 0, 22, 17, 34, 'Burberry pour mon fiston', 35, 100, 'Pour vous procurez ce produit, contacter nous sur WhatsApp au +243892465600', '1621673520_FreBerry.jpg', 'Burberry, kids fashion, habillement enfant'),
(134, 0, 12, 22, 2, 'KingMak KM5500ox', 10, 100, 'dÃ©penses', '1622874839_Hennessy.jpg', 'Nokia Smart'),
(135, 0, 23, 8, 37, 'Hydraulic Construction & Engineering Environment SARLU', 200, 1, 'L\'adresse du site est: hcee-org.cd', '1704804055_logo2.jpg', 'hcee'),
(137, 0, 12, 1, 3, 'iPhone 7 plus', 115, 23, 'contactez-nous sur whatsapp au', '1706008385_1552670718_iphone-7-plus.jpg', 'iPhone'),
(138, 0, 20, 66, 32, 'Pizza', 10, 65, 'food', '1706687147_pizza.PNG', 'pizza'),
(139, 0, 17, 20, 37, 'Ballon', 15, 1000, 'ballon', '1706690325_ballon.JPG', 'ballon'),
(140, 0, 19, 3, 17, 'microphone', 200, 23, 'microphone', '1706755305_microphone-en-arriere-plan-avec-musique-700-1919.jpg', 'micro'),
(141, 0, 19, 3, 17, 'Horloge', 20, 100, 'contacter nous au 0976564216', '1706755236_la-fin-du-changement-dheure-a-letude.jpg', 'horloge'),
(143, 6, 17, 22, 17, 'Timberlands', 70, 100, 'contactez nous sur Whatsapp au +243 993 685 089', '1707240707_1707118291_87be3a89-a39b-429a-a570-9c45c51f1089.png', 'Timberland'),
(144, 6, 16, 17, 17, 'Pantalon', 15, 50, 'Contactez-nous sur Whatsapp au +243 980 547 290', '1707245502_Screenshot_20240205-183312_Instagram.jpg', 'Pantalon, Versace'),
(145, 9, 16, 18, 34, 'Robe', 30, 20, 'Contactez-nous au +243 980 547 290', '1707245747_Screenshot_20240205-182825_Instagram.jpg', 'robe'),
(146, 6, 17, 16, 34, 'JACKET', 25, 30, 'Tricot Jacket', '1707292028_Screenshot_20240201-104302_Instagram.jpg', 'jacket'),
(147, 6, 17, 22, 40, 'Timberland', 60, 40, 'Nous contacter sur Whatsapp au +243 976 564 216', '1707294502_Screenshot_20240203-093518_WhatsAppBusiness.jpg', 'timberland'),
(148, 6, 17, 22, 40, 'Timberland', 80, 10, 'Bonne qualité et nouveauté', '1707294596_Screenshot_20240201-164922_WhatsApp.jpg', 'timberland'),
(149, 9, 17, 63, 42, 'Chapeau', 15, 370, 'chapeau', '1707294693_Screenshot_20240201-104239_Instagram.jpg', 'chapeau'),
(150, 2, 19, 10, 2, 'Power Bank', 25, 290, 'nouveauté', '1707294825_Screenshot_20240201-104247_Instagram.jpg', 'power bank'),
(151, 2, 27, 14, 8, 'Bag', 15, 90, 'bag à vendre', '1707295001_Screenshot_20240201-104350_Instagram.jpg', 'Bag, cartable'),
(152, 4, 19, 3, 33, 'Montre', 35, 86, 'montre', '1707295181_Screenshot_20240205-183252_Instagram.jpg', 'MONTRE'),
(153, 9, 26, 23, 42, 'Tricot', 15, 79, 'tricot', '1707295692_Screenshot_20240205-183159_Instagram.jpg', 'tricot'),
(154, 2, 17, 22, 43, 'Ketch', 20, 49, 'shoes', '1707295985_Screenshot_20240205-183149_Instagram.jpg', 'SHOES'),
(155, 2, 27, 23, 39, 'Cagoule', 5, 16, 'Cagoule à bonne qualité', '1707302764_Screenshot_20240201-104241_Instagram.jpg', 'cagoule'),
(156, 2, 27, 67, 39, 'Tricot', 10, 70, 'tricot de bonne qualité', '1707302820_Screenshot_20240204-012823_WhatsAppBusiness.jpg', 'tricot, cagoule'),
(157, 2, 26, 23, 44, 'Lacoste', 12, 29, 'Procurez-vous des polos Lacoste à un prix abordable', '1707303538_Screenshot_20240205-182848_Instagram.jpg', 'Lacoste, Polo'),
(158, 3, 12, 11, 7, 'Tablette', 230, 40, 'Contactez nous physiquement pour en savoir plus au Galerie SION, dans la ville de Butembo/Nord-kivu/RDC.', '1707303935_Screenshot_20240205-183239_Instagram.jpg', 'tablettes '),
(159, 2, 27, 22, 38, 'Perpette ', 18, 54, 'perpette de qualité', '1707304143_Screenshot_20240205-183143_Instagram.jpg', 'perpette'),
(160, 9, 15, 39, 36, 'Brillant ', 7, 100, 'Un produit pour la décor de vos lèvres', '1707304395_Screenshot_20240205-183209_Instagram.jpg', 'brillant'),
(161, 2, 27, 23, 39, 'Complet', 15, 20, 'Complet', '1707304552_Screenshot_20240205-182818_Instagram.jpg', 'complet'),
(162, 2, 22, 18, 35, 'Robe', 13, 70, 'Robe ', '1707304637_Screenshot_20240205-182829_Instagram.jpg', 'ROBE'),
(163, 2, 26, 23, 39, 'Complet', 15, 35, 'Un complet destiné pour les hommes et les femmes', '1707304765_Screenshot_20240205-183153_Instagram.jpg', 'complet'),
(164, 3, 19, 47, 10, 'Microphone', 120, 9, 'Microphone', '1707305349_Screenshot_20240201-104252_Instagram.jpg', 'micro'),
(165, 10, 22, 17, 39, 'complet', 15, 46, 'complet', '1707305468_Screenshot_20240205-182854_Instagram.jpg', 'Complet'),
(166, 10, 26, 23, 42, 'Training', 5, 77, 'Training de sport', '1707305590_Screenshot_20240201-104327_Instagram.jpg', 'training'),
(167, 3, 12, 1, 3, 'iPhone 13 pro Max', 1700, 269, 'nouveau modèle', '1707305859_Screenshot_20240201-104333_Instagram.jpg', 'iphone'),
(168, 3, 12, 3, 9, 'Air Pod', 15, 33, 'Air pod', '1707306248_Screenshot_20240201-104339_Instagram.jpg', 'air pod'),
(169, 10, 17, 3, 47, 'COHIBA', 45, 80, 'cohiba tabat', '1707306517_Screenshot_20240201-104257_Instagram.jpg', 'cohiba'),
(170, 10, 22, 18, 39, 'Jolie robe pour Ma Princesse', 10, 64, 'Une robe pour ma petite fille', '1707311316_Screenshot_20240205-182900_Instagram.jpg', 'robe'),
(171, 10, 17, 17, 39, 'Complet', 25, 45, 'poche bombé', '1707311502_Screenshot_20240205-183204_Instagram.jpg', 'complet'),
(172, 4, 12, 1, 3, 'Phone du Future', 95, 33, 'un telephone avec un BT', '1707641129_Screenshot_20240201-104345_Instagram.jpg', 'iphone'),
(173, 2, 27, 22, 38, 'Basket Pour Sportif', 35, 88, 'des baskets de haute qualite', '1707641288_Screenshot_20240201-104311_Instagram.jpg', 'basket'),
(174, 2, 26, 23, 39, 'Polos Avec Griffe', 10, 160, 'contacter nous sur Whatsapp au +243-976-564-216', '1707641525_Screenshot_20240205-183257_Instagram.jpg', 'polo'),
(175, 9, 15, 3, 37, 'Equipement de Muscu', 50, 20, 'équipement de musculation', '1707641785_Screenshot_20240205-183302_Instagram.jpg', 'musculation'),
(176, 6, 26, 16, 38, 'Timberland Pour Artiste', 70, 33, 'timerland', '1707641884_Screenshot_20240203-093505_WhatsAppBusiness.jpg', 'timerland');

-- --------------------------------------------------------

--
-- Structure de la table `shops`
--

DROP TABLE IF EXISTS `shops`;
CREATE TABLE IF NOT EXISTS `shops` (
  `shop_id` int(11) NOT NULL AUTO_INCREMENT,
  `shop_cat` varchar(40) DEFAULT NULL,
  `shop_title` varchar(40) NOT NULL,
  `shop_address` varchar(40) NOT NULL,
  `shop_contact_1` varchar(13) NOT NULL,
  `shop_contact_2` varchar(13) NOT NULL,
  `shop_image` text NOT NULL,
  PRIMARY KEY (`shop_id`)
) ENGINE=MyISAM AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Déchargement des données de la table `shops`
--

INSERT INTO `shops` (`shop_id`, `shop_cat`, `shop_title`, `shop_address`, `shop_contact_1`, `shop_contact_2`, `shop_image`) VALUES
(1, '1', 'CACIM', 'Butembo, Lukanga, Uniluk', '+243976564216', '+243985745533', '1706772969_CACIM 20230710_120838.jpg'),
(2, '4', 'Kwetu Shop', 'Butembo, Gallery SION', '0976564216', '0985745533', '1706773161_24d92019cbb1bf578ce554bfaab4d8fd.jpg'),
(3, '3', 'smartGadgetry', 'Butembo, Gallery SION', '+243977237230', '+243977237230', '1706782104_smart.PNG'),
(4, '2', 'Atelog', 'Butembo, Av. Baye', '0976564216', '0976564216', '1706787717_1619170199_gec.png'),
(5, '8', 'Timbeland', 'Kinshasa', '0976564216', '0976564216', '1707049499_1621013418_Albertino_shoes.jpg'),
(6, '8', 'Sam Shop', 'Kinshasa', '0976564216', '0985745533', '1707198106_1707118288_87be3a89-a39b-429a-a570-9c45c51f1089.png'),
(7, '3', 'Kasoki Restau', 'Butembo', '0976564216', '0976564216', '1707198137_1707195994_aaf4b029f0_115550_infusion.jpg'),
(9, '1', 'Make-Up Shop', 'Lukanga', '0976564216', '0980547290', '1707245602_Screenshot_20240202-130223_Lite.jpg'),
(10, '1', 'Chocolat Shop', 'Butembo', '0976564216', '0985745533', '1707305161_Screenshot_20240201-104257_Instagram.jpg');

-- --------------------------------------------------------

--
-- Structure de la table `sous_categories`
--

DROP TABLE IF EXISTS `sous_categories`;
CREATE TABLE IF NOT EXISTS `sous_categories` (
  `sous_cat_id` int(11) NOT NULL AUTO_INCREMENT,
  `sous_cat_title` text DEFAULT NULL,
  PRIMARY KEY (`sous_cat_id`)
) ENGINE=MyISAM AUTO_INCREMENT=68 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `sous_categories`
--

INSERT INTO `sous_categories` (`sous_cat_id`, `sous_cat_title`) VALUES
(1, 'Mobiles'),
(2, 'Ordinateurs'),
(3, 'Accessoires'),
(6, 'Chargeurs'),
(8, 'Logiciel de gestion'),
(9, 'Reseaux sociaux'),
(10, 'Power Bank'),
(11, 'Tablets'),
(12, 'Laptops'),
(13, 'Printers & Ink'),
(14, 'School Bags'),
(15, 'Girls Shoes'),
(16, 'Boys Shoes'),
(17, 'Boys Clothing'),
(18, 'Girls Clothing'),
(19, 'Underwear'),
(20, 'Sportwear'),
(21, 'Bags & Wallets'),
(22, 'Shoes'),
(23, 'Clothing'),
(24, 'Watches'),
(25, 'Travels Bags & Backpacks'),
(26, 'Jewelry'),
(27, 'Eyewear'),
(28, 'Sports Shoes'),
(29, 'Televisions'),
(30, 'Cameras'),
(31, 'Headphones'),
(32, 'Speakers'),
(33, 'Drives & Storage'),
(34, 'Cases & Covers'),
(35, 'Cleaning Products'),
(36, 'Coffe, Tea & Beverages'),
(37, 'Cooking Ingredients'),
(38, 'Perfumes'),
(39, 'Make-Up'),
(40, 'Skin Care'),
(41, 'Dental Care'),
(42, 'Bath & Body'),
(43, 'Hear Care & Styling'),
(44, 'Luxury Beauty'),
(45, 'Personal Care Appliances'),
(46, 'Toilettage masculin'),
(47, 'Musical Instruments'),
(48, 'Washing Machines'),
(49, 'Coffee Makers'),
(50, 'Juice Makers'),
(51, 'Lingerie & Sleepwear'),
(52, 'Keybords & Mice'),
(53, 'Android'),
(54, 'Iphone'),
(55, 'Harmony OS'),
(56, 'Kitchen Accessories'),
(57, 'Furniture'),
(58, 'Kitchen & Dining'),
(59, 'Cookware'),
(60, 'Tableware'),
(61, 'Bakeware'),
(62, 'Bed & Bath'),
(63, 'Home Decor'),
(64, 'Lamps & Lighting'),
(65, 'Generateur'),
(66, 'Nutrition et Regime'),
(67, 'cagoule');

-- --------------------------------------------------------

--
-- Structure de la table `user_info`
--

DROP TABLE IF EXISTS `user_info`;
CREATE TABLE IF NOT EXISTS `user_info` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(100) NOT NULL,
  `last_name` varchar(100) NOT NULL,
  `email` varchar(300) NOT NULL,
  `password` varchar(300) NOT NULL,
  `mobile` varchar(10) NOT NULL,
  `address1` varchar(300) NOT NULL,
  `address2` varchar(11) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `user_info`
--

INSERT INTO `user_info` (`user_id`, `first_name`, `last_name`, `email`, `password`, `mobile`, `address1`, `address2`) VALUES
(1, 'toto', 'burefu', 'toto@gmail.com', '81dc9bdb52d04dc20036dbd8313ed055', '991458589', 'Butembo', 'Rue matadi'),
(3, 'titi', 'de titi', 'titi@gmail.com', 'e807f1fcf82d132f9bb018ca6738a19f', '0995616909', 'Rue de Buta', '0000000000'),
(4, 'pipi', 'pipi', 'pipi@gmail.com', '210b48b542659fb951a80a15c5997513', '0995616909', 'Rue de Buta', '0000000000'),
(5, 'david', 'mfalme', 'mfalmedavid@gmail.com', '9fe68918e19b6e8eb9592d579af55986', '0976564216', 'butembo', 'nord-kivu'),
(6, 'dimex', 'mollah', 'mollahdimex@gmail.com', 'd9e14627bb1c64e89f6bd530e0ff56f8', '0985745533', 'Butembo', 'Av Lubwe');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `products`
--
ALTER TABLE `products`
  ADD CONSTRAINT `fk_product_brand` FOREIGN KEY (`product_brand`) REFERENCES `brands` (`brand_id`),
  ADD CONSTRAINT `fk_product_cat` FOREIGN KEY (`product_cat`) REFERENCES `categories` (`cat_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
